def translate(text):
    return text
